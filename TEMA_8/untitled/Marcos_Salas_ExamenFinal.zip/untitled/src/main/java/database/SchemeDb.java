package database;

public interface SchemeDb {

            String host = "127.0.0.1:3306";
            String dtbs = "empresa1";
            String user = "root";
            String pass = "";
            String TAB_FACTURA = "factura";
            String COL_COMPANIA = "compania";
            String COL_PAIS = "pais";
            String COL_TELEFONO = "telefono";
            String COL_TOTAL = "total";



    }





