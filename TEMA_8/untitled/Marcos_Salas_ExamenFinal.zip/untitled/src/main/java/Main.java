import controller.Controller1;
import controller.Controller2;

public class Main {
    public static void main(String[] args) {

        Controller1 controladora1=new Controller1();

      controladora1.lecturaFichero();

    //    Controller2 controller2=new Controller2();
       //  controller2.leerFicheros();


    }
}
